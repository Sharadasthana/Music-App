$(document).ready(function() {

    $('#menu').click(function() {
        $(this).toggleClass('fas-times');
        $('.navbar').toggleClass('nav-toggle');
    });
    $(window).on('load scroll', function() {
        $('#menu').removeClass('fas-times');
        $('.navbar').removeClass('nav-toggle');
    });

    function can() {

    }
});